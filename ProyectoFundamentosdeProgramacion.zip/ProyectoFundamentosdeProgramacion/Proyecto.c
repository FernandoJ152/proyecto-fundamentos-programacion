#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define arch_trabajadores "trabajadores.in"
#define arch_departamento "departamento.txt"
#define arch_extrabajadores "extrabajadores.txt"
#define arch_cargo "cargo.txt"

typedef struct
{
	int CI, depNum, carNum, dia, mes, año;
	char nombre[30], dep[15], car[15];
	float sueldo;
} tipo_trabajador; //registro con los datos de los trabajadores

int n, k, dato;
tipo_trabajador lista[100]; //arreglo de registro de trabajadores
FILE *trabajadores, *departamento, *extrabajadores, *cargo;
char dep[15], car[15], buffer[256], nom2[30], nomMinSuel[30], nomMaxSuel[30], refElim[10];
int opcion, i, l, p, o, j = 0, m, n, bandera = 0, cedi, idDep, idCar, sumDep = 0, sumCar = 0, motElim, elimMes, elimDia, elimAño;
float sumSuelCar = 0, sumSuelDep = 0, maxSuel = 0, minSuel = 999999999;
//declaración de variables

void numDepCar(int c, int d);
int validacionFecha(int d, int m, int y);
void numElim(int e);
void buscarCI(int cedula);
void llenarDep(int idDep);
void llenarCar(int idCar);
void maxMinSuel();
void elimTrab();//definición de acciones nominadas

void numDepCar(int c, int d)
{
	switch (c)
	{
	case 1:
		strcpy(lista[k].dep, "RRHH");
		break;

	case 2:
		strcpy(lista[k].dep, "Consultoria");
		break;

	case 3:
		strcpy(lista[k].dep, "Diseno");
		break;

	case 4:
		strcpy(lista[k].dep, "Produccion");
		break;

	case 5:
		strcpy(lista[k].dep, "Calidad");
		break;

	case 6:
		strcpy(lista[k].dep, "Distribucion");
		break;
	}

	switch (d)
	{
	case 1:
		strcpy(lista[k].car, "Gerente");
		break;

	case 2:
		strcpy(lista[k].car, "Supervisor");
		break;

	case 3:
		strcpy(lista[k].car, "Analista");
		break;

	case 4:
		strcpy(lista[k].car, "Disenador");
		break;

	case 5:
		strcpy(lista[k].car, "Desarrollador");
		break;

	case 6:
		strcpy(lista[k].car, "Auditor");
		break; //asignación de nombre de departamento y cargo al registro, según su código
	}
}

int validacionFecha(int d, int m, int y)
{
	int validD, validM, validY;
	if (y > 0 && y < 2024)
	{ //verificación de año
		validY = 1;
	}
	else
	{
		validY = 0;
	}
	if (m > 0 && m < 13)
	{ //verificación de mes
		validM = 1;
	}
	else
	{
		validM = 0;
	}
	if (d > 0 && d < 32 && !(d > 30 && (m == 2 || m == 4 || m == 6 || m == 9 || m == 11)) && !(d > 28 && m == 2))
	{ //verificación de día
		validD = 1;
	}
	else
	{
		validD = 0;
	}
	return (validD == 1 && validM == 1 && validY == 1); //sólo regresa verdadero si la fecha es correcta
}

void numElim(int e)
{
	switch (e)
	{
	case 1:
		strcpy(refElim, "Traslado");
		break;

	case 2:
		strcpy(refElim, "Renuncia");
		break;

	case 3:
		strcpy(refElim, "Despido");
		break;

	case 4:
		strcpy(refElim, "Otro");
		break; //asignación de motivo de eliminación al registro, según su código
	}
}

void llenarArchivo()
{
	for (k = 1; k <= j; k++)
	{
		numDepCar(lista[k].depNum, lista[k].carNum);																																				  //procedimiento para llenar nombre de departamento/cargo según código numérico
		fprintf(trabajadores, "%-10d %-32s %-15s %-15s %2d/%2d/%4d %-10.2f \n", lista[k].CI, lista[k].nombre, lista[k].dep, lista[k].car, lista[k].dia, lista[k].mes, lista[k].año, lista[k].sueldo); //se escriben todos los valores del registro al archivo de trabajadores
	}
}

void buscarCI(int cedula)
{
	bandera = 0;
	for (l = 1; l <= j; l++)
	{
		if (cedula == lista[l].CI)
		{
			bandera = 1;
			break; //búsqueda de cédula ingresada en el arreglo
		}
	}
}

void llenarDep(int idDep)
{
	for (m = 1; m <= j; m++)
	{
		if (idDep == lista[m].depNum)
		{
			sumDep++;
			fprintf(departamento, "%-10d %-32s %-15s %-15s %-2d/%-2d/%-4d %-10.2f\n", lista[m].CI, lista[m].nombre, lista[m].dep, lista[m].car, lista[m].dia, lista[m].mes, lista[m].año, lista[m].sueldo); //escritura de los datos de los trabajadores la archivo según departamento
			sumSuelDep = sumSuelDep + lista[m].sueldo;																																						//sumatoria de los sueldos de los trabajadores que correspondan a cierto departamento
		}
	}
	if (sumDep == 0)
	{
		printf("No hay trabajadores con este departamento");
	}
	else
	{
		printf("Total de trabajadores del departamento %s: %d\nTotal de sueldos devengados por este departamento: %.2f\n", lista[m].dep, sumDep, sumSuelDep);
		sumSuelDep = 0;
		sumDep = 0; //reinicio de las variables para ser usada por otro departamento
	}
}

void llenarCar(int idCar)
{
	for (m = 1; m <= j; m++)
	{
		if (idCar == lista[m].carNum)
		{
			sumCar++;
			fprintf(cargo, "%-10d %-32s %-15s %-15s %-2d/%-2d/%-4d %-10.2f\n", lista[m].CI, lista[m].nombre, lista[m].dep, lista[m].car, lista[m].dia, lista[m].mes, lista[m].año, lista[m].sueldo); //escritura de los datos de los trabajadores al archivo según cargo
			sumSuelCar = sumSuelCar + lista[m].sueldo;																																				 //sumatoria de los sueldos de los trabajadores que correspondan a cierto cargo
		}
	}
	if (sumCar == 0)
	{
		printf("No hay trabajadores con este cargo");
	}
	else
	{
		printf("Total de trabajadores del cargo %s: %d\nTotal de sueldos devengados por este cargo: %.2f\n", lista[m].car, sumCar, sumSuelCar);
		sumSuelCar = 0;
		sumCar = 0; //reinicio de las variables para ser usada por otro cargo
	}
}

void maxMinSuel()
{
	for (o = 1; o <= j; o++)
	{
		if (lista[o].sueldo < minSuel)
		{
			strcpy(nomMinSuel, lista[o].nombre);
			minSuel = lista[o].sueldo; //verificación si un mínimo sueldo se ha alcanzado
		}
		if (lista[o].sueldo > maxSuel)
		{
			strcpy(nomMaxSuel, lista[o].nombre);
			maxSuel = lista[o].sueldo; //verificación si un máximo sueldo se ha alcanzado
		}
	}
	printf("\nEl trabajador con el menor sueldo es %s.", nomMinSuel);
	printf("\nEl trabajador con el mayor sueldo es %s.\n", nomMaxSuel); //se imprimen los valores finales de las variables mínimo/máximo
	maxSuel = 0;
	minSuel = 999999999; //reinicio de variables, ya que se pueden eliminar los trabajadores a los que correspondían sus valores
}

void elimTrab()
{
	for (p = l; p < j; p++)
	{
		lista[p] = lista[p + 1]; //desplazo de valores del registro a partir del índice eliminado
	}
	j = j - 1; //reducción de cantidad total de trabajadores
	freopen(arch_trabajadores, "w", trabajadores);
	llenarArchivo(); //limpieza y reintroducción de valores al archivo, esta vez sin el valor borrado
}

int main()
{//inicio
	trabajadores = fopen(arch_trabajadores, "w");
	departamento = fopen(arch_departamento, "w");
	extrabajadores = fopen(arch_extrabajadores, "w");
	cargo = fopen(arch_cargo, "w"); //apertura de archivos
	do
	{
		printf("\nOPCIONES\n\n[1] Ingresar\n[2] Consultar\n[3] Modificar\n[4] Eliminar\n[5] Salir\n\n"); //menú de opciones
		scanf("%d", &opcion);
		switch (opcion)
		{
		case 1:
			printf("Ingrese cantidad de trabajadores a ingresar: ");
			scanf("%d", &n);
			for (i = 1; i <= n; i++)
			{		 //ciclo para ingreso de datos
				j++; //acumulador de cantidad total de trabajadores
				printf("\nTRABAJADOR %d\n\n", j);
				printf("Cedula: ");
				scanf(" %d", &lista[j].CI);
				printf("\nNombre (max 30 caracteres): ");
				scanf(" %30[^\n]s", &lista[j].nombre);
				printf("\nDepartamento: (1: RRHH, 2: Consultoria, 3: Diseno, 4: Produccion, 5: Calidad, 6: Distribucion): ");
				scanf("%d", &lista[j].depNum);
				printf("\nCargo (1: Gerente, 2: Supervisor, 3: Analista, 4: Disenador, 5: Desarrollador, 6: Auditor): ");
				scanf("%d", &lista[j].carNum);
				numDepCar(lista[j].depNum, lista[j].carNum); //llamado a función para asignar nombre a cargo/departamento según número identificador
				printf("\nSueldo: ");
				scanf("%f", &lista[j].sueldo);
				do
				{
					printf("\nFecha de ingreso (escribir en formato DD MM YYYY): ");
					scanf("%d %d %d", &lista[j].dia, &lista[j].mes, &lista[j].año);
					if (!validacionFecha(lista[j].dia, lista[j].mes, lista[j].año))
					{ //verificación de fecha
						printf("\nFecha invalida");
					}
				} while (!validacionFecha(lista[j].dia, lista[j].mes, lista[j].año));
			}
			llenarArchivo(); //ingreso de dato entrados al archivo
			break;

		case 2:
		if(j == 0){
			printf("No hay trabajadores a consultar");
			break;
			}
			else{
			printf("\n1: Consulta por CI\n2: Consulta por departamento\n3: Consulta por cargo\n4: Mayor y menor sueldo\n"); //menú de opciones
			scanf("%d", &opcion);
			switch (opcion)
			{
			case 1:
				printf("Ingrese cedula a consultar: ");
				scanf("%d", &cedi);
				buscarCI(cedi); //búsqueda de cédula ingresada en archivo
				if (bandera == 0)
				{
					printf("\nCedula no encontrada");
					break;
				}
				else
				{
					printf("\nNombre: %s\nDepartamento:  %s\nCargo: %s\nSueldo: %.2f\nFecha de ingreso: %d/%d/%d\n", lista[l].nombre, lista[l].dep, lista[l].car, lista[l].sueldo, lista[l].dia, lista[l].mes, lista[l].año); //datos del trabajador consultado
					break;
				}

			case 2:
				printf("Ingrese identificador de departamento (1: RRHH, 2: Consultoria, 3: Diseno, 4: Produccion, 5: Calidad, 6: Distribucion): ");
				scanf("%d", &idDep);
				llenarDep(idDep); //llamado a procedimiento para llenar archivo departamentos
				break;

			case 3:
				printf("Ingrese identificador de cargo (1: Gerente, 2: Supervisor, 3: Analista, 4: Disenador, 5: Desarrollador, 6: Auditor): ");
				scanf("%d", &idCar);
				llenarCar(idCar); //llamado a procedimiento para llenar archivo cargos
				break;

			case 4:
				maxMinSuel(); //llamado a procedimiento para calcular máximo/mínimo sueldo
				break;

			default:
				printf("Invalido");
				break;
			}
			break;
			}

		case 3:
			printf("Ingrese CI del trabajador a modificar: ");
			scanf("%d", &cedi);
			buscarCI(cedi); //búsqueda de cédula ingresada en archivo
			if (bandera == 0)
			{
				printf("Cedula no encontrada");
				break;
			}
			else
			{
				printf("Ingrese dato a cambiar: 1: Nombre, 2: Departamento, 3: Cargo, 4: Sueldo, 5: Fecha de ingreso ");
				scanf("%d", &dato);
				switch (dato)
				{
				case 1:
					printf("Ingrese nuevo nombre: ");
					scanf(" %30[^\n]s", &nom2);
					strcpy(lista[l].nombre, nom2); //asignación de nombre nuevo del trabajador
					break;

				case 2:
					printf("Ingrese nuevo departamento (1: RRHH, 2: Consultoria, 3: Diseno, 4: Produccion, 5: Calidad, 6: Distribucion): ");
					scanf("%d", &lista[l].depNum); //asignación de identificador departamento nuevo del trabajador
					break;

				case 3:
					printf("Ingrese nuevo cargo (1: Gerente, 2: Supervisor, 3: Analista, 4: Disenador, 5: Desarrollador, 6: Auditor): ");
					scanf("%d", &lista[l].carNum); //asignación de identificador de cargo nuevo del trabajador
					break;

				case 4:
					printf("Ingrese nuevo sueldo: ");
					scanf("%f", &lista[l].sueldo); //asignación de sueldo nuevo del trabajador
					break;

				case 5:
					do
					{
						printf("Ingrese nueva fecha de ingreso (DD MM YYYY): ");
						scanf("%d %d %d", &lista[l].dia, &lista[l].mes, &lista[l].año); //asignación de fecha de ingreso nueva del trabajador
						if (!validacionFecha(lista[l].dia, lista[l].mes, lista[l].año))
						{ //verificación de fecha
							printf("\nFecha invalida\n");
						}
					} while (!validacionFecha(lista[l].dia, lista[l].mes, lista[l].año));
					break;

				default:
					printf("Dato invalido\n");
				}
				freopen(arch_trabajadores, "w", trabajadores);
				llenarArchivo(); //limpieza de archivo y reingreso de datos con nueva información
			}
			break;

		case 4:
			printf("Ingrese CI a eliminar: ");
			scanf("%d", &cedi);
			buscarCI(cedi); //búsqueda de cédula ingresada en archivo
			if (bandera == 0)
			{
				printf("Cedula no encontrada");
				break;
			}
			else
			{
				printf("Datos del trabajador:\n\nNombre: %s\nDepartamento: %s\nCargo: %s\nSueldo: %.2f\nFecha de ingreso: %d/%d/%d\n\n¿Borrar estos datos?\n\n1: Si\n2: No\n", lista[l].nombre, lista[l].dep, lista[l].car, lista[l].sueldo, lista[l].dia, lista[l].mes, lista[l].año); //datos de trabajador consultado, con confirmación si se desean eliminar o no
				scanf("%d", &opcion);
				switch (opcion)
				{
				case 2:
					break; //ruptura de switch al negar eliminación

				case 1:
					printf("Indicar motivo de eliminacion (1: Traslado, 2: Renuncia, 3: Despido, 4: Otro): ");
					scanf("%d", &motElim);
					numElim(motElim); //asignación de motivo de eliminación según identificador numérico
					do
					{
						printf("Indicar fecha de eliminacion (DD MM YYYY): ");
						scanf("%d %d %d", &elimDia, &elimMes, &elimAño); //fecha de eliminación
						if (!validacionFecha(elimDia, elimMes, elimAño))
						{ //verificación de fecha
							printf("\nFecha invalida\n");
						}
					} while (!validacionFecha(elimDia, elimMes, elimAño));
					fprintf(extrabajadores, "%-10d %-32s %-15s %-15s %d/%d/%d %-10.2f %-10s %-2d/%-2d/%-4d\n", lista[l].CI, lista[l].nombre, lista[l].dep, lista[l].car, lista[l].dia, lista[l].mes, lista[l].año, lista[l].sueldo, refElim, elimDia, elimMes, elimAño); //se llena archivo de ex-trabajadores con datos eliminados, junto a motivo y fecha
					elimTrab();																																																											 //procedimiento para reescribir archivo sin los datos borrados
					break;

				default:
					printf("Invalido\n");
					break;
				}
			}
			break;

		case 5:
			return 0; //terminación del programa
			break;

		default:
			printf("VALOR INVALIDO");
			break;
		}

	} while (opcion != 5);

	fclose(trabajadores);
	fclose(departamento);
	fclose(extrabajadores);
	fclose(cargo); //cierro de archivos
	return 0;
}